Brightcove Video Embed Field
----------------------------
This module parses a Brightcove URL via the Video Embed Field

Example URL: http://link.brightcove.com/services/player/bcpid3303744435001?bckey=AQ~~,AAAAAGL7jok~,vslbwQw3pdWM_Ya9IsUVNvJJIhV9YG1S&bctid=3118695475001
